package com.smartportal.model;

import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "tenders")
public class Tender {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(length = 2000)
    private String description;

    private String category; // Infrastructure, Technology, Supply Chain

    // Minimum 1 week duration enforced in service
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate endDate;

    // Deadline = endDate at 23:59:59
    private LocalDateTime deadline;

    private Double estimatedBudget;

    // OPEN, CLOSED, CANCELLED
    private String status = "OPEN";

    // Winner = lowest bidder (declared within 1 hour after deadline)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private User createdBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "winner_id")
    private User winner;

    private Double winningBid;
    private LocalDateTime createdAt = LocalDateTime.now();
    private boolean resultDeclared = false;
    private LocalDateTime resultDeclaredAt;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public LocalDateTime getDeadline() {
		return deadline;
	}
	public void setDeadline(LocalDateTime deadline) {
		this.deadline = deadline;
	}
	public Double getEstimatedBudget() {
		return estimatedBudget;
	}
	public void setEstimatedBudget(Double estimatedBudget) {
		this.estimatedBudget = estimatedBudget;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public User getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	public User getWinner() {
		return winner;
	}
	public void setWinner(User winner) {
		this.winner = winner;
	}
	public Double getWinningBid() {
		return winningBid;
	}
	public void setWinningBid(Double winningBid) {
		this.winningBid = winningBid;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public boolean isResultDeclared() {
		return resultDeclared;
	}
	public void setResultDeclared(boolean resultDeclared) {
		this.resultDeclared = resultDeclared;
	}
	public LocalDateTime getResultDeclaredAt() {
		return resultDeclaredAt;
	}
	public void setResultDeclaredAt(LocalDateTime resultDeclaredAt) {
		this.resultDeclaredAt = resultDeclaredAt;
	}

    
}