package com.smartportal.controller;

import com.smartportal.model.User;
import com.smartportal.service.AuthService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @GetMapping("/login")
    public String showLogin() {
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam String email,
                               @RequestParam String password,
                               HttpSession session,
                               RedirectAttributes ra) {

        String role = authService.login(email, password);

        if (role == null) {
            ra.addFlashAttribute("error",
                "❌ Invalid email or password. Please try again.");
            return "redirect:/login";
        }

        if ("BLOCKED".equals(role)) {
            ra.addFlashAttribute("error",
                "🚫 Your account has been blocked. Contact admin.");
            return "redirect:/login";
        }

        // Store session
        session.setAttribute("loggedInUser", email);
        session.setAttribute("userRole",     role);

        // Store user's display name for navbar
        if (!"admin".equalsIgnoreCase(email)) {
            authService.getUserByEmail(email).ifPresent(u ->
                session.setAttribute("userName", u.getName()));
        } else {
            session.setAttribute("userName", "Admin");
        }

        // Redirect by role
        switch (role) {
            case "ADMIN":      return "redirect:/admin/dashboard";
            case "GOVERNMENT": return "redirect:/government/dashboard";
            case "COMPANY":    return "redirect:/company/dashboard";
            default:           return "redirect:/user/dashboard";
        }
    }

    @GetMapping("/signup")
    public String showSignup(Model model) {
        model.addAttribute("user", new User());
        return "signup";
    }

    @PostMapping("/signup")
    public String processSignup(@ModelAttribute User user,
                                @RequestParam String role,
                                RedirectAttributes ra) {
        user.setRole(role.toUpperCase());

        if (role.equalsIgnoreCase("USER")) {
            user.setOrganisation(null);
        }

        String result = authService.signup(user);

        switch (result) {
            case "EMAIL_EXISTS":
                ra.addFlashAttribute("error",
                    "An account with this email already exists.");
                return "redirect:/signup";
            case "MOBILE_EXISTS":
                ra.addFlashAttribute("error",
                    "An account with this mobile number already exists.");
                return "redirect:/signup";
            default:
                ra.addFlashAttribute("success",
                    "✅ Account created! Please login.");
                return "redirect:/login";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session, RedirectAttributes ra) {
        session.invalidate();
        ra.addFlashAttribute("success", "Logged out successfully.");
        return "redirect:/login";
    }
}