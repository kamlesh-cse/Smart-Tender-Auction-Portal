package com.smartportal.controller;

import com.smartportal.model.*;
import com.smartportal.repository.UserRepository;
import com.smartportal.service.AuctionService;
import com.smartportal.service.TenderService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Controller
@RequestMapping("/company")
public class CompanyController {

    private final AuctionService  auctionService;
    private final TenderService   tenderService;
    private final UserRepository  userRepository;

    private final String UPLOAD_DIR =
        System.getProperty("user.home") + "/smartportal-uploads/";

    public CompanyController(AuctionService auctionService,
                             TenderService tenderService,
                             UserRepository userRepository) {
        this.auctionService = auctionService;
        this.tenderService  = tenderService;
        this.userRepository = userRepository;
    }

    // ── Helpers ────────────────────────────────────────
    private User getLoggedInUser(HttpSession session) {
        String email = (String) session.getAttribute("loggedInUser");
        if (email == null) return null;
        return userRepository.findByEmail(email).orElse(null);
    }

    private void addMeta(Model model, HttpSession session) {
        User user = getLoggedInUser(session);
        if (user != null) {
            model.addAttribute("companyName", user.getName());
            model.addAttribute("companyOrg",  user.getOrganisation());
            model.addAttribute("companyUser", user);
        }
    }

    private boolean isNotCompany(HttpSession session) {
        String role = (String) session.getAttribute("userRole");
        return !"COMPANY".equals(role);
    }

    // ══════════════════════════════════════════════════
    //  DASHBOARD
    // ══════════════════════════════════════════════════
    @GetMapping({"/", "/dashboard"})
    public String dashboard(Model model, HttpSession session) {
        if (isNotCompany(session)) return "redirect:/login";
        addMeta(model, session);
        User user = getLoggedInUser(session);

        // Auctions created by this company
        List<Auction> myAuctions = auctionService.getByCreatedBy(user);
        // Bids placed by this company on auctions
        List<AuctionBid> myAuctionBids = auctionService.getBidsByUser(user);
        // Tenders created by this company
        List<Auction> myCreatedAuctions = auctionService.getByCreatedBy(user);
        // Tender proposals submitted by this company
        List<TenderBid> myTenderBids = tenderService.getBidsByCompany(user);

        model.addAttribute("myAuctions",    myAuctions);
        model.addAttribute("myAuctionBids", myAuctionBids);
        model.addAttribute("myTenderBids",  myTenderBids);
        model.addAttribute("openAuctions",  auctionService.getOpen().size());
        model.addAttribute("openTenders",   tenderService.getOpen().size());
        model.addAttribute("wonAuctions",
            myAuctionBids.stream()
                .filter(b -> b.getAuction().getWinner() != null
                    && b.getAuction().getWinner().getId().equals(user.getId()))
                .count());
        model.addAttribute("wonTenders",
            myTenderBids.stream()
                .filter(b -> b.getTender().getWinner() != null
                    && b.getTender().getWinner().getId().equals(user.getId()))
                .count());

        return "company/dashboard";
    }

    // ══════════════════════════════════════════════════
    //  BROWSE & BID ON AUCTIONS
    // ══════════════════════════════════════════════════
    @GetMapping("/auctions")
    public String browseAuctions(Model model, HttpSession session) {
        if (isNotCompany(session)) return "redirect:/login";
        addMeta(model, session);
        model.addAttribute("auctions", auctionService.getAll());
        return "company/list_auction";
    }

    @GetMapping("/auction/view/{id}")
    public String viewAuction(@PathVariable Long id,
                              Model model, HttpSession session) {
        if (isNotCompany(session)) return "redirect:/login";
        addMeta(model, session);
        Auction auction = auctionService.getById(id);
        if (auction == null) return "redirect:/company/auctions";
        model.addAttribute("auction", auction);
        model.addAttribute("bids", auctionService.getBidsForAuction(id));

        // Check if this company already bid
        User user = getLoggedInUser(session);
        boolean alreadyBid = auctionService.getBidsForAuction(id).stream()
            .anyMatch(b -> b.getBidder().getId().equals(user.getId()));
        model.addAttribute("alreadyBid", alreadyBid);
        model.addAttribute("isOwner",
            auction.getCreatedBy() != null
                && auction.getCreatedBy().getId().equals(user.getId()));

        return "company/view_auction";
    }

    @PostMapping("/auction/bid/{id}")
    public String placeBid(@PathVariable Long id,
                           @RequestParam Double bidAmount,
                           HttpSession session,
                           RedirectAttributes ra) {
        if (isNotCompany(session)) return "redirect:/login";
        User user = getLoggedInUser(session);

        String result = auctionService.placeBid(id, user, bidAmount);
        switch (result) {
            case "SUCCESS":
                ra.addFlashAttribute("success", "✅ Bid placed successfully!");
                break;
            case "BID_TOO_LOW":
                ra.addFlashAttribute("error",
                    "❌ Bid must be higher than the current highest bid.");
                break;
            case "OWN_AUCTION":
                ra.addFlashAttribute("error",
                    "❌ You cannot bid on your own auction.");
                break;
            case "ALREADY_CLOSED":
                ra.addFlashAttribute("error",
                    "❌ This auction is closed.");
                break;
            default:
                ra.addFlashAttribute("error", "❌ Could not place bid.");
        }
        return "redirect:/company/auction/view/" + id;
    }

    // ── Company's own auctions (create/manage) ─────────
    @GetMapping("/my-auctions")
    public String myAuctions(Model model, HttpSession session) {
        if (isNotCompany(session)) return "redirect:/login";
        addMeta(model, session);
        User user = getLoggedInUser(session);
        model.addAttribute("auctions", auctionService.getByCreatedBy(user));
        return "company/my_auctions";
    }

    @GetMapping("/auction/create")
    public String createAuctionForm(Model model, HttpSession session) {
        if (isNotCompany(session)) return "redirect:/login";
        addMeta(model, session);
        model.addAttribute("auction", new Auction());
        return "company/create_auction";
    }

    @PostMapping("/auction/save")
    public String saveAuction(@ModelAttribute Auction auction,
                              @RequestParam(value = "imageFile", required = false)
                              MultipartFile file,
                              HttpSession session,
                              RedirectAttributes ra) throws IOException {
        if (isNotCompany(session)) return "redirect:/login";
        User user = getLoggedInUser(session);
        auction.setCreatedBy(user);

        if (file != null && !file.isEmpty()) {
            String fileName = System.currentTimeMillis()
                + "_" + file.getOriginalFilename();
            Path uploadPath = Paths.get(UPLOAD_DIR);
            Files.createDirectories(uploadPath);
            file.transferTo(uploadPath.resolve(fileName));
            auction.setPhoto(fileName);
        } else if (auction.getId() != null) {
            Auction existing = auctionService.getById(auction.getId());
            if (existing != null) auction.setPhoto(existing.getPhoto());
        }

        if (auction.getDurationMinutes() != null
                && auction.getDurationMinutes() < 30) {
            ra.addFlashAttribute("error",
                "Auction duration must be at least 30 minutes.");
            return "redirect:/company/auction/create";
        }

        auctionService.save(auction);
        ra.addFlashAttribute("success", "Auction published!");
        return "redirect:/company/my-auctions";
    }

    @GetMapping("/auction/edit/{id}")
    public String editAuction(@PathVariable Long id,
                              Model model, HttpSession session) {
        if (isNotCompany(session)) return "redirect:/login";
        addMeta(model, session);
        Auction auction = auctionService.getById(id);
        if (auction == null) return "redirect:/company/my-auctions";
        model.addAttribute("auction", auction);
        return "company/update_auction";
    }

    @GetMapping("/auction/delete/{id}")
    public String deleteAuction(@PathVariable Long id,
                                RedirectAttributes ra) {
        auctionService.delete(id);
        ra.addFlashAttribute("success", "Auction deleted.");
        return "redirect:/company/my-auctions";
    }

    // ── My Auction Bids ────────────────────────────────
    @GetMapping("/my-bids")
    public String myBids(Model model, HttpSession session) {
        if (isNotCompany(session)) return "redirect:/login";
        addMeta(model, session);
        User user = getLoggedInUser(session);
        model.addAttribute("auctionBids", auctionService.getBidsByUser(user));
        model.addAttribute("tenderBids",  tenderService.getBidsByCompany(user));
        return "company/my_bids";
    }

    // ══════════════════════════════════════════════════
    //  TENDERS — Browse & Submit Proposals
    // ══════════════════════════════════════════════════
    @GetMapping("/tenders")
    public String browseTenders(Model model, HttpSession session) {
        if (isNotCompany(session)) return "redirect:/login";
        addMeta(model, session);
        model.addAttribute("tenders", tenderService.getOpen());
        return "company/list_tender";
    }

    @GetMapping("/tender/view/{id}")
    public String viewTender(@PathVariable Long id,
                             Model model, HttpSession session) {
        if (isNotCompany(session)) return "redirect:/login";
        addMeta(model, session);
        Tender tender = tenderService.getById(id);
        if (tender == null) return "redirect:/company/tenders";
        model.addAttribute("tender", tender);
        model.addAttribute("bids", tenderService.getBidsForTender(id));

        User user = getLoggedInUser(session);
        boolean alreadySubmitted = tenderService.getBidsForTender(id).stream()
            .anyMatch(b -> b.getCompany().getId().equals(user.getId()));
        model.addAttribute("alreadySubmitted", alreadySubmitted);

        return "company/view_tender";
    }

    @PostMapping("/tender/submit/{id}")
    public String submitTenderProposal(
            @PathVariable Long id,
            @RequestParam Double bidAmount,
            @RequestParam(required = false) String proposal,
            @RequestParam(value = "docFile", required = false) MultipartFile docFile,
            HttpSession session,
            RedirectAttributes ra) throws IOException {

        if (isNotCompany(session)) return "redirect:/login";
        User user = getLoggedInUser(session);

        String docPath = null;
        if (docFile != null && !docFile.isEmpty()) {
            String fileName = System.currentTimeMillis()
                + "_" + docFile.getOriginalFilename();
            Path uploadPath = Paths.get(UPLOAD_DIR);
            Files.createDirectories(uploadPath);
            docFile.transferTo(uploadPath.resolve(fileName));
            docPath = fileName;
        }

        String result = tenderService.fillTender(id, user, bidAmount, proposal, docPath);
        switch (result) {
            case "SUCCESS":
                ra.addFlashAttribute("success",
                    "✅ Proposal submitted successfully!");
                break;
            case "ALREADY_SUBMITTED":
                ra.addFlashAttribute("error",
                    "❌ You already submitted a proposal for this tender.");
                break;
            case "ALREADY_CLOSED":
                ra.addFlashAttribute("error",
                    "❌ This tender is no longer accepting proposals.");
                break;
            default:
                ra.addFlashAttribute("error", "❌ Could not submit proposal.");
        }
        return "redirect:/company/tender/view/" + id;
    }
}