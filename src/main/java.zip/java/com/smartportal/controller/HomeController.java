package com.smartportal.controller;

import com.smartportal.service.AuctionService;
import com.smartportal.service.TenderService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class HomeController {

    private final AuctionService auctionService;
    private final TenderService tenderService;

    public HomeController(AuctionService auctionService,
                          TenderService tenderService) {
        this.auctionService = auctionService;
        this.tenderService = tenderService;
    }

    // ── Home ───────────────────────────────────────────
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("totalAuctions",  auctionService.getAll().size());
        model.addAttribute("openAuctions",   auctionService.getOpen().size());
        model.addAttribute("totalTenders",   tenderService.getAll().size());
        model.addAttribute("openTenders",    tenderService.getOpen().size());
        model.addAttribute("recentAuctions", auctionService.getOpen());
        model.addAttribute("recentTenders",  tenderService.getOpen());
        return "index";
    }

    // ── Public Auction List ────────────────────────────
    @GetMapping("/auctions")
    public String auctions(Model model) {
        model.addAttribute("auctions", auctionService.getOpen());
        return "auction";
    }

    // ── Public Tender List ─────────────────────────────
    @GetMapping("/tenders")
    public String tenders(Model model) {
        model.addAttribute("tenders", tenderService.getOpen());
        return "tender";
    }

    // ── About ──────────────────────────────────────────
    @GetMapping("/about")
    public String about() { return "about"; }

    // ── Contact ────────────────────────────────────────
    @GetMapping("/contact")
    public String contact() { return "contact"; }

    @PostMapping("/contact")
    public String submitContact(@RequestParam String name,
                                @RequestParam String email,
                                @RequestParam String subject,
                                @RequestParam String message,
                                RedirectAttributes ra) {
        // Log it — email sending wired in later
        System.out.println("Contact from: " + name + " | " + email
            + " | " + subject + " | " + message);
        ra.addFlashAttribute("success",
            "Thank you " + name + "! We'll respond to " + email + " within 24 hours.");
        return "redirect:/contact";
    }
}