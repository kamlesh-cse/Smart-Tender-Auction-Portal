package com.smartportal.controller;

import com.smartportal.model.*;
import com.smartportal.repository.UserRepository;
import com.smartportal.service.AuctionService;
import com.smartportal.service.TenderService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

@Controller
@RequestMapping("/government")
public class GovernmentController {

    private final AuctionService  auctionService;
    private final TenderService   tenderService;
    private final UserRepository  userRepository;

    private final String UPLOAD_DIR =
        System.getProperty("user.home") + "/smartportal-uploads/";

    public GovernmentController(AuctionService auctionService,
                                TenderService tenderService,
                                UserRepository userRepository) {
        this.auctionService = auctionService;
        this.tenderService  = tenderService;
        this.userRepository = userRepository;
    }

    // ── Session helper ─────────────────────────────────
    private User getLoggedInUser(HttpSession session) {
        String email = (String) session.getAttribute("loggedInUser");
        if (email == null) return null;
        return userRepository.findByEmail(email).orElse(null);
    }

    private void addMeta(Model model, HttpSession session) {
        User user = getLoggedInUser(session);
        if (user != null) {
            model.addAttribute("govName", user.getName());
            model.addAttribute("govOrg",  user.getOrganisation());
            model.addAttribute("govUser", user);
        }
    }

    // ── Guard: redirect if not GOVERNMENT ──────────────
    private boolean isNotGovt(HttpSession session) {
        String role = (String) session.getAttribute("userRole");
        return !"GOVERNMENT".equals(role);
    }

    // ══════════════════════════════════════════════════
    //  DASHBOARD
    // ══════════════════════════════════════════════════
    @GetMapping({"/", "/dashboard"})
    public String dashboard(Model model, HttpSession session) {
        if (isNotGovt(session)) return "redirect:/login";
        addMeta(model, session);
        User user = getLoggedInUser(session);

        model.addAttribute("myAuctions",
            auctionService.getByCreatedBy(user));
        model.addAttribute("myTenders",
            tenderService.getByCreatedBy(user));
        model.addAttribute("openAuctions",
            auctionService.getOpenByUser(user).size());
        model.addAttribute("closedAuctions",
            auctionService.getClosedByUser(user).size());
        model.addAttribute("openTenders",
            tenderService.getOpenByUser(user).size());
        model.addAttribute("closedTenders",
            tenderService.getClosedByUser(user).size());

        return "government/dashboard";
    }

    // ══════════════════════════════════════════════════
    //  AUCTION MANAGEMENT
    // ══════════════════════════════════════════════════
    @GetMapping("/auctions")
    public String myAuctions(Model model, HttpSession session) {
        if (isNotGovt(session)) return "redirect:/login";
        addMeta(model, session);
        User user = getLoggedInUser(session);
        model.addAttribute("auctions", auctionService.getByCreatedBy(user));
        return "government/list_auction";
    }

    @GetMapping("/auction/create")
    public String createAuctionForm(Model model, HttpSession session) {
        if (isNotGovt(session)) return "redirect:/login";
        addMeta(model, session);
        model.addAttribute("auction", new Auction());
        return "government/create_auction";
    }

    @PostMapping("/auction/save")
    public String saveAuction(@ModelAttribute Auction auction,
                              @RequestParam(value = "imageFile", required = false)
                              MultipartFile file,
                              HttpSession session,
                              RedirectAttributes ra) throws IOException {
        if (isNotGovt(session)) return "redirect:/login";

        User user = getLoggedInUser(session);
        auction.setCreatedBy(user);

        // Image upload
        if (file != null && !file.isEmpty()) {
            String fileName = System.currentTimeMillis()
                + "_" + file.getOriginalFilename();
            Path uploadPath = Paths.get(UPLOAD_DIR);
            Files.createDirectories(uploadPath);
            file.transferTo(uploadPath.resolve(fileName));
            auction.setPhoto(fileName);
        } else if (auction.getId() != null) {
            Auction existing = auctionService.getById(auction.getId());
            if (existing != null) auction.setPhoto(existing.getPhoto());
        }

        if (auction.getDurationMinutes() != null
                && auction.getDurationMinutes() < 30) {
            ra.addFlashAttribute("error",
                "Auction duration must be at least 30 minutes.");
            return "redirect:/government/auction/create";
        }

        auctionService.save(auction);
        ra.addFlashAttribute("success", "Auction published successfully!");
        return "redirect:/government/auctions";
    }

    @GetMapping("/auction/edit/{id}")
    public String editAuction(@PathVariable Long id,
                              Model model, HttpSession session) {
        if (isNotGovt(session)) return "redirect:/login";
        addMeta(model, session);
        Auction auction = auctionService.getById(id);
        if (auction == null) return "redirect:/government/auctions";
        model.addAttribute("auction", auction);
        return "government/update_auction";
    }

    @GetMapping("/auction/delete/{id}")
    public String deleteAuction(@PathVariable Long id,
                                RedirectAttributes ra) {
        auctionService.delete(id);
        ra.addFlashAttribute("success", "Auction deleted.");
        return "redirect:/government/auctions";
    }

    @GetMapping("/auction/view/{id}")
    public String viewAuction(@PathVariable Long id,
                              Model model, HttpSession session) {
        if (isNotGovt(session)) return "redirect:/login";
        addMeta(model, session);
        Auction auction = auctionService.getById(id);
        if (auction == null) return "redirect:/government/auctions";
        model.addAttribute("auction", auction);
        model.addAttribute("bids", auctionService.getBidsForAuction(id));
        return "government/view_auction";
    }

    // ══════════════════════════════════════════════════
    //  TENDER MANAGEMENT
    // ══════════════════════════════════════════════════
    @GetMapping("/tenders")
    public String myTenders(Model model, HttpSession session) {
        if (isNotGovt(session)) return "redirect:/login";
        addMeta(model, session);
        User user = getLoggedInUser(session);
        model.addAttribute("tenders", tenderService.getByCreatedBy(user));
        return "government/list_tender";
    }

    @GetMapping("/tender/create")
    public String createTenderForm(Model model, HttpSession session) {
        if (isNotGovt(session)) return "redirect:/login";
        addMeta(model, session);
        model.addAttribute("tender", new Tender());
        return "government/create_tender";
    }

    @PostMapping("/tender/save")
    public String saveTender(@ModelAttribute Tender tender,
                             HttpSession session,
                             RedirectAttributes ra) {
        if (isNotGovt(session)) return "redirect:/login";

        User user = getLoggedInUser(session);
        tender.setCreatedBy(user);

        try {
            tenderService.save(tender);
            ra.addFlashAttribute("success", "Tender published successfully!");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/government/tender/create";
        }
        return "redirect:/government/tenders";
    }

    @GetMapping("/tender/edit/{id}")
    public String editTender(@PathVariable Long id,
                             Model model, HttpSession session) {
        if (isNotGovt(session)) return "redirect:/login";
        addMeta(model, session);
        Tender tender = tenderService.getById(id);
        if (tender == null) return "redirect:/government/tenders";
        model.addAttribute("tender", tender);
        return "government/update_tender";
    }

    @GetMapping("/tender/delete/{id}")
    public String deleteTender(@PathVariable Long id,
                               RedirectAttributes ra) {
        tenderService.delete(id);
        ra.addFlashAttribute("success", "Tender deleted.");
        return "redirect:/government/tenders";
    }

    @GetMapping("/tender/view/{id}")
    public String viewTender(@PathVariable Long id,
                             Model model, HttpSession session) {
        if (isNotGovt(session)) return "redirect:/login";
        addMeta(model, session);
        Tender tender = tenderService.getById(id);
        if (tender == null) return "redirect:/government/tenders";
        model.addAttribute("tender", tender);
        model.addAttribute("bids", tenderService.getBidsForTender(id));
        return "government/view_tender";
    }
}