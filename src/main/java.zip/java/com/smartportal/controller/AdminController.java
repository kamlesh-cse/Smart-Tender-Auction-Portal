package com.smartportal.controller;

import com.smartportal.model.*;
import com.smartportal.repository.UserRepository;
import com.smartportal.service.AuctionService;
import com.smartportal.service.TenderService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final AuctionService auctionService;
    private final TenderService  tenderService;
    private final UserRepository userRepository;

    private final String UPLOAD_DIR =
        System.getProperty("user.home") + "/smartportal-uploads/";

    public AdminController(AuctionService auctionService,
                           TenderService tenderService,
                           UserRepository userRepository) {
        this.auctionService = auctionService;
        this.tenderService  = tenderService;
        this.userRepository = userRepository;
    }

    // ── helper: add common model attributes ────────────
    private void addAdminMeta(Model model, HttpSession session) {
        model.addAttribute("adminName",
            session.getAttribute("loggedInUser") != null
                ? session.getAttribute("loggedInUser") : "Admin");
    }

    // ══════════════════════════════════════════════════
    //  DASHBOARD
    // ══════════════════════════════════════════════════
    @GetMapping({"/", "/dashboard"})
    public String dashboard(Model model, HttpSession session) {
        addAdminMeta(model, session);

        // Stats
        List<User> allUsers = userRepository.findAll();
        model.addAttribute("totalUsers",      allUsers.size());
        model.addAttribute("govtUsers",       userRepository.findByRole("GOVERNMENT").size());
        model.addAttribute("companyUsers",    userRepository.findByRole("COMPANY").size());
        model.addAttribute("regularUsers",    userRepository.findByRole("USER").size());

        model.addAttribute("totalAuctions",   auctionService.getAll().size());
        model.addAttribute("openAuctions",    auctionService.getOpen().size());
        model.addAttribute("closedAuctions",  auctionService.getClosed().size());

        model.addAttribute("totalTenders",    tenderService.getAll().size());
        model.addAttribute("openTenders",     tenderService.getOpen().size());
        model.addAttribute("closedTenders",   tenderService.getClosed().size());

        // Recent records
        model.addAttribute("recentAuctions",  auctionService.getAll()
            .stream().limit(5).toList());
        model.addAttribute("recentTenders",   tenderService.getAll()
            .stream().limit(5).toList());
        model.addAttribute("recentUsers",     allUsers
            .stream().limit(5).toList());

        return "admin/dashboard";
    }

    // ══════════════════════════════════════════════════
    //  USER MANAGEMENT
    // ══════════════════════════════════════════════════
    @GetMapping("/users")
    public String listUsers(Model model, HttpSession session) {
        addAdminMeta(model, session);
        model.addAttribute("users", userRepository.findAll());
        return "admin/users";
    }

    @GetMapping("/user/delete/{id}")
    public String deleteUser(@PathVariable Long id,
                             RedirectAttributes ra) {
        userRepository.deleteById(id);
        ra.addFlashAttribute("success", "User deleted successfully.");
        return "redirect:/admin/users";
    }

    @GetMapping("/user/toggle/{id}")
    public String toggleUser(@PathVariable Long id,
                             RedirectAttributes ra) {
        userRepository.findById(id).ifPresent(u -> {
            u.setActive(!u.isActive());
            userRepository.save(u);
        });
        ra.addFlashAttribute("success", "User status updated.");
        return "redirect:/admin/users";
    }

    // ══════════════════════════════════════════════════
    //  AUCTION MANAGEMENT
    // ══════════════════════════════════════════════════
    @GetMapping("/auctions")
    public String listAuctions(Model model, HttpSession session) {
        addAdminMeta(model, session);
        model.addAttribute("auctions", auctionService.getAll());
        return "admin/list_auction";
    }

    @GetMapping("/auction/create")
    public String createAuctionForm(Model model, HttpSession session) {
        addAdminMeta(model, session);
        model.addAttribute("auction", new Auction());
        return "admin/create_auction";
    }

    @PostMapping("/auction/save")
    public String saveAuction(@ModelAttribute Auction auction,
                              @RequestParam(value = "imageFile", required = false)
                              MultipartFile file,
                              HttpSession session,
                              RedirectAttributes ra) throws IOException {

        // Set creator from session
        String email = (String) session.getAttribute("loggedInUser");
        if (email != null && !email.equals("admin")) {
            userRepository.findByEmail(email)
                .ifPresent(auction::setCreatedBy);
        }

        // Handle image
        if (file != null && !file.isEmpty()) {
            String fileName = System.currentTimeMillis()
                + "_" + file.getOriginalFilename();
            Path uploadPath = Paths.get(UPLOAD_DIR);
            Files.createDirectories(uploadPath);
            file.transferTo(uploadPath.resolve(fileName));
            auction.setPhoto(fileName);
        } else if (auction.getId() != null) {
            Auction existing = auctionService.getById(auction.getId());
            if (existing != null) auction.setPhoto(existing.getPhoto());
        }

        // Validate min 30 minutes
        if (auction.getDurationMinutes() != null
                && auction.getDurationMinutes() < 30) {
            ra.addFlashAttribute("error",
                "Auction duration must be at least 30 minutes.");
            return "redirect:/admin/auction/create";
        }

        auctionService.save(auction);
        ra.addFlashAttribute("success", "Auction saved successfully!");
        return "redirect:/admin/auctions";
    }

    @GetMapping("/auction/edit/{id}")
    public String editAuction(@PathVariable Long id,
                              Model model, HttpSession session) {
        addAdminMeta(model, session);
        Auction auction = auctionService.getById(id);
        if (auction == null) return "redirect:/admin/auctions";
        model.addAttribute("auction", auction);
        return "admin/update_auction";
    }

    @GetMapping("/auction/delete/{id}")
    public String deleteAuction(@PathVariable Long id,
                                RedirectAttributes ra) {
        auctionService.delete(id);
        ra.addFlashAttribute("success", "Auction deleted.");
        return "redirect:/admin/auctions";
    }

    @GetMapping("/auction/view/{id}")
    public String viewAuction(@PathVariable Long id,
                              Model model, HttpSession session) {
        addAdminMeta(model, session);
        Auction auction = auctionService.getById(id);
        if (auction == null) return "redirect:/admin/auctions";
        model.addAttribute("auction", auction);
        model.addAttribute("bids",
            auctionService.getBidsForAuction(id));
        return "admin/view_auction";
    }

    // ══════════════════════════════════════════════════
    //  TENDER MANAGEMENT
    // ══════════════════════════════════════════════════
    @GetMapping("/tenders")
    public String listTenders(Model model, HttpSession session) {
        addAdminMeta(model, session);
        model.addAttribute("tenders", tenderService.getAll());
        return "admin/list_tender";
    }

    @GetMapping("/tender/create")
    public String createTenderForm(Model model, HttpSession session) {
        addAdminMeta(model, session);
        model.addAttribute("tender", new Tender());
        return "admin/create_tender";
    }

    @PostMapping("/tender/save")
    public String saveTender(@ModelAttribute Tender tender,
                             HttpSession session,
                             RedirectAttributes ra) {
        // Set creator
        String email = (String) session.getAttribute("loggedInUser");
        if (email != null && !email.equals("admin")) {
            userRepository.findByEmail(email)
                .ifPresent(tender::setCreatedBy);
        }

        try {
            tenderService.save(tender);
            ra.addFlashAttribute("success", "Tender saved successfully!");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/admin/tender/create";
        }
        return "redirect:/admin/tenders";
    }

    @GetMapping("/tender/edit/{id}")
    public String editTender(@PathVariable Long id,
                             Model model, HttpSession session) {
        addAdminMeta(model, session);
        Tender tender = tenderService.getById(id);
        if (tender == null) return "redirect:/admin/tenders";
        model.addAttribute("tender", tender);
        return "admin/update_tender";
    }

    @GetMapping("/tender/delete/{id}")
    public String deleteTender(@PathVariable Long id,
                               RedirectAttributes ra) {
        tenderService.delete(id);
        ra.addFlashAttribute("success", "Tender deleted.");
        return "redirect:/admin/tenders";
    }

    @GetMapping("/tender/view/{id}")
    public String viewTender(@PathVariable Long id,
                             Model model, HttpSession session) {
        addAdminMeta(model, session);
        Tender tender = tenderService.getById(id);
        if (tender == null) return "redirect:/admin/tenders";
        model.addAttribute("tender", tender);
        model.addAttribute("bids",
            tenderService.getBidsForTender(id));
        return "admin/view_tender";
    }
}