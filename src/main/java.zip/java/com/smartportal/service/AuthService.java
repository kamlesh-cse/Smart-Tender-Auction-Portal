package com.smartportal.service;

import com.smartportal.model.User;
import com.smartportal.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class AuthService {

    private final UserRepository userRepository;

    public AuthService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // ── Login ──────────────────────────────────────────
    public String login(String emailOrUsername, String password) {

        // Hardcoded Admin
        if ("admin".equalsIgnoreCase(emailOrUsername)
                && "admin123".equals(password)) {
            return "ADMIN";
        }

        // Database Users
        Optional<User> optUser = userRepository.findByEmail(emailOrUsername);
        if (optUser.isEmpty()) return null;

        User user = optUser.get();

        // Password check (plain text for now)
        if (!user.getPassword().equals(password)) return null;

        // Check if active
        if (!user.isActive()) return "BLOCKED";

        // Update last login
        user.setLastLogin(LocalDateTime.now());
        userRepository.save(user);

        return user.getRole();
    }

    // ── Signup ─────────────────────────────────────────
    public String signup(User user) {

        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            return "EMAIL_EXISTS";
        }

        if (userRepository.findByMobile(user.getMobile()).isPresent()) {
            return "MOBILE_EXISTS";
        }

        user.setActive(true);
        user.setCreatedAt(LocalDateTime.now());

        userRepository.save(user);
        return "SUCCESS";
    }

    // ── Get User By Email ─────────────────────────────
    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }
}