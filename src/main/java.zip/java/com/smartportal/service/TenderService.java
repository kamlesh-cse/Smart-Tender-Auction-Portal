package com.smartportal.service;

import com.smartportal.model.*;
import com.smartportal.repository.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class TenderService {

    private final TenderRepository tenderRepository;
    private final TenderBidRepository bidRepository;

    public TenderService(TenderRepository tenderRepository,
                         TenderBidRepository bidRepository) {
        this.tenderRepository = tenderRepository;
        this.bidRepository = bidRepository;
    }

    // ── Save Tender ────────────────────────────────────
    public Tender save(Tender tender) {

        if (tender.getStartDate() != null && tender.getEndDate() != null) {

            long days = ChronoUnit.DAYS.between(
                    tender.getStartDate(),
                    tender.getEndDate());

            if (days < 7) {
                throw new IllegalArgumentException(
                        "Tender duration must be at least 1 week (7 days).");
            }
        }

        // Deadline = end of endDate
        if (tender.getEndDate() != null) {
            tender.setDeadline(
                    tender.getEndDate().atTime(LocalTime.MAX));
        }

        return tenderRepository.save(tender);
    }

    // ── Basic Fetch Methods ────────────────────────────
    public List<Tender> getAll() {
        return tenderRepository.findAll();
    }

    public List<Tender> getOpen() {
        return tenderRepository.findByStatus("OPEN");
    }

    public List<Tender> getClosed() {
        return tenderRepository.findByStatus("CLOSED");
    }

    public Tender getById(Long id) {
        return tenderRepository.findById(id).orElse(null);
    }

    public void delete(Long id) {
        tenderRepository.deleteById(id);
    }

    // ── By Creator (Using ID) ──────────────────────────
    public List<Tender> getByCreator(Long userId) {
        return tenderRepository.findByCreatedById(userId);
    }

    // ── NEW: By Creator (Using User Object) ────────────
    public List<Tender> getByCreatedBy(User user) {
        return tenderRepository.findByCreatedBy(user);
    }

    public List<Tender> getOpenByUser(User user) {
        return tenderRepository.findByCreatedByAndStatus(user, "OPEN");
    }

    public List<Tender> getClosedByUser(User user) {
        return tenderRepository.findByCreatedByAndStatus(user, "CLOSED");
    }

    // ── Fill Tender (Company Only) ─────────────────────
    // Returns:
    // "NOT_FOUND", "ALREADY_CLOSED", "ALREADY_SUBMITTED", "SUCCESS"
    public String fillTender(Long tenderId,
                             User company,
                             Double amount,
                             String proposal,
                             String documentPath) {

        Tender tender = getById(tenderId);
        if (tender == null) return "NOT_FOUND";

        if (!"OPEN".equals(tender.getStatus()))
            return "ALREADY_CLOSED";

        if (LocalDateTime.now().isAfter(tender.getDeadline()))
            return "ALREADY_CLOSED";

        // Only one submission per company per tender
        if (bidRepository.existsByTenderIdAndCompanyId(
                tenderId, company.getId())) {

            return "ALREADY_SUBMITTED";
        }

        TenderBid bid = new TenderBid();
        bid.setTender(tender);
        bid.setCompany(company);
        bid.setBidAmount(amount);
        bid.setProposal(proposal);
        bid.setDocumentPath(documentPath);

        bidRepository.save(bid);

        return "SUCCESS";
    }

    public List<TenderBid> getBidsForTender(Long tenderId) {
        return bidRepository.findByTenderIdOrderByBidAmountAsc(tenderId);
    }
    
 // Add this method to TenderService

    public List<TenderBid> getBidsByCompany(User user) {
        return bidRepository.findByCompanyId(user.getId());
    }
    
}