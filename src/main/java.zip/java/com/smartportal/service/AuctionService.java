package com.smartportal.service;

import com.smartportal.model.*;
import com.smartportal.repository.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AuctionService {

    private final AuctionRepository auctionRepository;
    private final AuctionBidRepository bidRepository;
    private final EmailService emailService;

    public AuctionService(AuctionRepository auctionRepository,
                          AuctionBidRepository bidRepository,
                          EmailService emailService) {
        this.auctionRepository = auctionRepository;
        this.bidRepository = bidRepository;
        this.emailService = emailService;
    }

    // ── Save Auction ───────────────────────────────────
    public Auction save(Auction auction) {

        if (auction.getAuctionDate() != null &&
            auction.getAuctionTime() != null &&
            auction.getDurationMinutes() != null) {

            LocalDateTime start = LocalDateTime.of(
                    auction.getAuctionDate(),
                    auction.getAuctionTime());

            auction.setDeadline(start.plusMinutes(auction.getDurationMinutes()));
        }

        return auctionRepository.save(auction);
    }

    // ── Basic Fetch Methods ────────────────────────────
    public List<Auction> getAll() {
        return auctionRepository.findAll();
    }

    public List<Auction> getOpen() {
        return auctionRepository.findByStatus("OPEN");
    }

    public List<Auction> getClosed() {
        return auctionRepository.findByStatus("CLOSED");
    }

    public Auction getById(Long id) {
        return auctionRepository.findById(id).orElse(null);
    }

    public void delete(Long id) {
        auctionRepository.deleteById(id);
    }

    // ── By Creator (Using ID) ──────────────────────────
    public List<Auction> getByCreator(Long userId) {
        return auctionRepository.findByCreatedById(userId);
    }

    // ── NEW: By Creator (Using User Object) ────────────
    public List<Auction> getByCreatedBy(User user) {
        return auctionRepository.findByCreatedBy(user);
    }

    public List<Auction> getOpenByUser(User user) {
        return auctionRepository.findByCreatedByAndStatus(user, "OPEN");
    }

    public List<Auction> getClosedByUser(User user) {
        return auctionRepository.findByCreatedByAndStatus(user, "CLOSED");
    }

    // ── Place Bid ──────────────────────────────────────
    public String placeBid(Long auctionId, User bidder, Double amount) {

        Auction auction = getById(auctionId);
        if (auction == null) return "NOT_FOUND";

        if (!"OPEN".equals(auction.getStatus()))
            return "ALREADY_CLOSED";

        if (auction.getCreatedBy() != null &&
            auction.getCreatedBy().getId().equals(bidder.getId())) {
            return "OWN_AUCTION";
        }

        double minimum = auction.getCurrentHighestBid() > 0
                ? auction.getCurrentHighestBid()
                : auction.getStartingPrice();

        if (amount <= minimum)
            return "BID_TOO_LOW";

        if (LocalDateTime.now().isAfter(auction.getDeadline()))
            return "ALREADY_CLOSED";

        AuctionBid bid = new AuctionBid();
        bid.setAuction(auction);
        bid.setBidder(bidder);
        bid.setBidAmount(amount);

        bidRepository.save(bid);

        auction.setCurrentHighestBid(amount);
        auctionRepository.save(auction);

        return "SUCCESS";
    }

    public List<AuctionBid> getBidsForAuction(Long auctionId) {
        return bidRepository.findByAuctionIdOrderByBidAmountDesc(auctionId);
    }
    
 // Add these two methods to AuctionService

    public List<AuctionBid> getBidsByUser(User user) {
        return bidRepository.findByBidderId(user.getId());
    }
}