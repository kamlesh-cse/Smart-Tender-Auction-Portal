package com.smartportal.service;

import org.springframework.stereotype.Service;

@Service
public class EmailService {

    // ── All methods log to console instead of sending email ──
    // ── When ready: add spring-boot-starter-mail to pom.xml ──
    // ── and replace this class with the JavaMailSender version ──

    public void sendEmail(String to, String subject, String htmlBody) {
        System.out.println("========== EMAIL (STUB) ==========");
        System.out.println("TO      : " + to);
        System.out.println("SUBJECT : " + subject);
        System.out.println("BODY    : [HTML content - " + htmlBody.length() + " chars]");
        System.out.println("==================================");
    }

    // ── Signup Email ───────────────────────────────────
    public void sendSignupEmail(String to, String name, String role) {
        System.out.println("[EMAIL] Signup welcome → " + to
            + " | Name: " + name + " | Role: " + role);
    }

    // ── Login Email ────────────────────────────────────
    public void sendLoginEmail(String to, String name) {
        System.out.println("[EMAIL] Login alert → " + to + " | Name: " + name);
    }

    // ── Auction Created Email ──────────────────────────
    public void sendAuctionCreatedEmail(String to, String name,
                                        String auctionTitle, String deadline) {
        System.out.println("[EMAIL] Auction created → " + to
            + " | Auction: " + auctionTitle
            + " | Deadline: " + deadline);
    }

    // ── Tender Created Email ───────────────────────────
    public void sendTenderCreatedEmail(String to, String name,
                                       String tenderTitle, String deadline) {
        System.out.println("[EMAIL] Tender created → " + to
            + " | Tender: " + tenderTitle
            + " | Deadline: " + deadline);
    }

    // ── Auction Winner Email ───────────────────────────
    public void sendAuctionWinnerEmail(String to, String name,
                                       String auctionTitle, Double winningBid) {
        System.out.println("[EMAIL] Auction winner → " + to
            + " | Auction: " + auctionTitle
            + " | Winning Bid: ₹" + winningBid);
    }

    // ── Tender Winner Email ────────────────────────────
    public void sendTenderWinnerEmail(String to, String name,
                                      String tenderTitle, Double winningBid) {
        System.out.println("[EMAIL] Tender winner → " + to
            + " | Tender: " + tenderTitle
            + " | Winning Bid: ₹" + winningBid);
    }

    // ── Result Notification to Creator ────────────────
    public void sendResultToCreator(String to, String name,
                                    String title, String winnerName,
                                    Double winningAmount, String type) {
        System.out.println("[EMAIL] Result to creator → " + to
            + " | " + type + ": " + title
            + " | Winner: " + winnerName
            + " | Amount: ₹" + winningAmount);
    }

    // ── Notify Losing Participants ─────────────────────
    public void sendLoserNotification(String to, String name,
                                      String title, String type) {
        System.out.println("[EMAIL] Loser notification → " + to
            + " | " + type + ": " + title);
    }
}