package com.smartportal.repository;

import com.smartportal.model.Auction;
import com.smartportal.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface AuctionRepository extends JpaRepository<Auction, Long> {

    // Basic status filtering
    List<Auction> findByStatus(String status);

    // By creator using ID
    List<Auction> findByCreatedById(Long userId);

    // By creator using User object
    List<Auction> findByCreatedBy(User createdBy);

    // By creator + status
    List<Auction> findByCreatedByAndStatus(User createdBy, String status);

    // Auto-close logic support
    List<Auction> findByStatusAndDeadlineBefore(String status, LocalDateTime now);
}