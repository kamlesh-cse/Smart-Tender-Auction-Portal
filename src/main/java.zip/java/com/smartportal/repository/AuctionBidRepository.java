package com.smartportal.repository;

import com.smartportal.model.AuctionBid;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface AuctionBidRepository extends JpaRepository<AuctionBid, Long> {
    List<AuctionBid> findByAuctionIdOrderByBidAmountDesc(Long auctionId);
    Optional<AuctionBid> findTopByAuctionIdOrderByBidAmountDesc(Long auctionId);
    boolean existsByAuctionIdAndBidderId(Long auctionId, Long bidderId);
    List<AuctionBid> findByBidderId(Long bidderId);
}