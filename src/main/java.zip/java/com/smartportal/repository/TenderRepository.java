package com.smartportal.repository;

import com.smartportal.model.Tender;
import com.smartportal.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface TenderRepository extends JpaRepository<Tender, Long> {

    // Basic status filtering
    List<Tender> findByStatus(String status);

    // By creator using ID
    List<Tender> findByCreatedById(Long userId);

    // By creator using User object
    List<Tender> findByCreatedBy(User createdBy);

    // By creator + status
    List<Tender> findByCreatedByAndStatus(User createdBy, String status);

    // For automatic closing / result declaration
    List<Tender> findByStatusAndDeadlineBeforeAndResultDeclaredFalse(
            String status,
            LocalDateTime now
    );
}