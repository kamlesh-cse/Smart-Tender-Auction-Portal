package com.smartportal.repository;

import com.smartportal.model.TenderBid;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface TenderBidRepository extends JpaRepository<TenderBid, Long> {
    List<TenderBid> findByTenderIdOrderByBidAmountAsc(Long tenderId);
    Optional<TenderBid> findTopByTenderIdOrderByBidAmountAsc(Long tenderId);
    boolean existsByTenderIdAndCompanyId(Long tenderId, Long companyId);
    List<TenderBid> findByCompanyId(Long companyId);
}