package com.smartportal.scheduler;

import com.smartportal.model.*;
import com.smartportal.repository.*;
import com.smartportal.service.EmailService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Component
public class AuctionScheduler {

    private final AuctionRepository auctionRepository;
    private final TenderRepository tenderRepository;
    private final AuctionBidRepository auctionBidRepository;
    private final TenderBidRepository tenderBidRepository;
    private final EmailService emailService;

    public AuctionScheduler(AuctionRepository auctionRepository,
                             TenderRepository tenderRepository,
                             AuctionBidRepository auctionBidRepository,
                             TenderBidRepository tenderBidRepository,
                             EmailService emailService) {
        this.auctionRepository = auctionRepository;
        this.tenderRepository = tenderRepository;
        this.auctionBidRepository = auctionBidRepository;
        this.tenderBidRepository = tenderBidRepository;
        this.emailService = emailService;
    }

    // ── Auto-close Auctions every 1 minute ────────────
    @Scheduled(fixedRate = 60000)
    @Transactional
    public void closeExpiredAuctions() {
        List<Auction> expired = auctionRepository
            .findByStatusAndDeadlineBefore("OPEN", LocalDateTime.now());

        for (Auction auction : expired) {
            auction.setStatus("CLOSED");

            // Find highest bidder
            Optional<AuctionBid> topBid = auctionBidRepository
                .findTopByAuctionIdOrderByBidAmountDesc(auction.getId());

            if (topBid.isPresent()) {
                AuctionBid winBid = topBid.get();
                auction.setWinner(winBid.getBidder());
                auction.setCurrentHighestBid(winBid.getBidAmount());
                auction.setResultDeclared(true);
                auctionRepository.save(auction);

                // Notify winner
                emailService.sendAuctionWinnerEmail(
                    winBid.getBidder().getEmail(),
                    winBid.getBidder().getName(),
                    auction.getTitle(),
                    winBid.getBidAmount()
                );

                // Notify creator
                if (auction.getCreatedBy() != null) {
                    emailService.sendResultToCreator(
                        auction.getCreatedBy().getEmail(),
                        auction.getCreatedBy().getName(),
                        auction.getTitle(),
                        winBid.getBidder().getName(),
                        winBid.getBidAmount(),
                        "Auction"
                    );
                }

                // Notify losers
                List<AuctionBid> allBids = auctionBidRepository
                    .findByAuctionIdOrderByBidAmountDesc(auction.getId());
                for (AuctionBid bid : allBids) {
                    if (!bid.getBidder().getId().equals(winBid.getBidder().getId())) {
                        emailService.sendLoserNotification(
                            bid.getBidder().getEmail(),
                            bid.getBidder().getName(),
                            auction.getTitle(), "Auction"
                        );
                    }
                }
            } else {
                // No bids
                auction.setResultDeclared(true);
                auctionRepository.save(auction);
            }
        }
    }

    // ── Auto-close Tenders — result within 1 hour ─────
    // Check every 5 minutes for tenders to close
    @Scheduled(fixedRate = 300000)
    @Transactional
    public void closeExpiredTenders() {
        // Tenders past deadline + result not yet declared
        List<Tender> expired = tenderRepository
            .findByStatusAndDeadlineBeforeAndResultDeclaredFalse(
                "OPEN", LocalDateTime.now());

        for (Tender tender : expired) {
            tender.setStatus("CLOSED");

            // Find lowest bidder (winner)
            Optional<TenderBid> lowestBid = tenderBidRepository
                .findTopByTenderIdOrderByBidAmountAsc(tender.getId());

            if (lowestBid.isPresent()) {
                TenderBid winBid = lowestBid.get();
                tender.setWinner(winBid.getCompany());
                tender.setWinningBid(winBid.getBidAmount());
                tender.setResultDeclared(true);
                tender.setResultDeclaredAt(LocalDateTime.now());
                tenderRepository.save(tender);

                // Notify winner
                emailService.sendTenderWinnerEmail(
                    winBid.getCompany().getEmail(),
                    winBid.getCompany().getName(),
                    tender.getTitle(),
                    winBid.getBidAmount()
                );

                // Notify creator
                if (tender.getCreatedBy() != null) {
                    emailService.sendResultToCreator(
                        tender.getCreatedBy().getEmail(),
                        tender.getCreatedBy().getName(),
                        tender.getTitle(),
                        winBid.getCompany().getName(),
                        winBid.getBidAmount(),
                        "Tender"
                    );
                }

                // Notify losing companies
                List<TenderBid> allBids = tenderBidRepository
                    .findByTenderIdOrderByBidAmountAsc(tender.getId());
                for (TenderBid bid : allBids) {
                    if (!bid.getCompany().getId().equals(winBid.getCompany().getId())) {
                        emailService.sendLoserNotification(
                            bid.getCompany().getEmail(),
                            bid.getCompany().getName(),
                            tender.getTitle(), "Tender"
                        );
                    }
                }
            } else {
                tender.setResultDeclared(true);
                tender.setResultDeclaredAt(LocalDateTime.now());
                tenderRepository.save(tender);
            }
        }
    }
}